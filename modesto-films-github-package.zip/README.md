# Modesto Films - Película Automotiva e Acessórios 🚗✨

Site institucional da Modesto Films, especialista em películas automotivas e acessórios.

## 🔗 Acesse online
Após publicar no GitHub Pages:
`https://SEU_USUARIO.github.io/modesto-films`

## 📁 Conteúdo
- Página única responsiva (HTML + Tailwind CSS)
- Seções: Serviços, Galeria, Depoimentos, Mapa, Contato
- Integrações: WhatsApp, Instagram, Formulário via Formspree

## 📦 Como publicar
1. Faça upload do arquivo `index.html` neste repositório
2. Vá em **Settings > Pages** e ative GitHub Pages a partir da branch `main`

## ✨ Contato
Instagram: [@modestofilm](https://www.instagram.com/modestofilm)
